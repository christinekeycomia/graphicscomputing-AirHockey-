package com.airhockey.android.util;

public class LoggerConfig {
	public static final boolean ON = true;
}
